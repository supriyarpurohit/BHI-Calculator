import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

final Color mainHexColor = HexColor("#1C1C1C");
final Color accentHexColor = HexColor("FCC91C");
